// Load sales data from JSON file
fetch('sales-data.json')
    .then(response => response.json())
    .then(salesData => {
        processData(salesData);
    });

function processData(salesData) {
    // Calculate month-over-month change for percentage
    const enrichedData = salesData.map((item, index) => {
        let percentChange = null;
        let trend = '';

        if (index > 0) {
            percentChange = item.Perc - salesData[index - 1].Perc;
            trend = percentChange > 0 ? '<i class="fa-solid fa-arrow-trend-up"></i>' : percentChange < 0 ? '<i class="fa-solid fa-arrow-trend-down"></i>' : '<i class="fa-solid fa-minus"></i>';
        }

        return {
            ...item,
            PercentChange: percentChange,
            Trend: trend
        };
    });

    // Log to console
    console.log('Raw Sales Data (JSON):', salesData);
    console.log('Note: "Perc" represents percentage values that fluctuate month-to-month');
    console.table(enrichedData);

    // Create Chart.js chart
    const ctx = document.getElementById('salesChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: enrichedData.map(item => item.Month),
            datasets: [{
                label: 'Sales',
                data: enrichedData.map(item => item.Sales_Figure),
                backgroundColor: '#5A99EE',
                borderColor: '#4986D9',
                borderWidth: 0,
                borderRadius: 4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    enabled: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 45,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    },
                    ticks: {
                        font: {
                            family: "'Poppins', sans-serif",
                            size: 10
                        }
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            family: "'Poppins', sans-serif",
                            size: 10
                        }
                    }
                }
            }
        }
    });

    // Populate the data list in the HTML
    const dataTableBody = document.getElementById('dataTableBody');
    enrichedData.forEach((item, index) => {
        const row = document.createElement('tr');

        let percentChangeCell = '';
        let percentCellClass = 'percent-neutral';

        if (index === 0) {
            percentChangeCell = '-';
        } else {
            const changeStr = item.PercentChange > 0 ? `+${item.PercentChange}%` : `${item.PercentChange}%`;
            percentChangeCell = `${item.Trend} ${changeStr}`;
            percentCellClass = item.PercentChange > 0 ? 'percent-positive' : 'percent-negative';
        }

        row.innerHTML = `
            <td>${item.Month}</td>
            <td>${item.Sales_Figure}</td>
            <td><div class="percent-cell ${percentCellClass}">${percentChangeCell}</div></td>
        `;

        dataTableBody.appendChild(row);
    });

    // Log with formatted output showing trend analysis
    console.group('Month-over-Month Percentage Trend Analysis');
    enrichedData.forEach((item, index) => {
        if (index === 0) {
            console.log(`${item.Month}: Percentage = ${item.Perc}% (Baseline - No previous month)`);
        } else {
            const change = item.PercentChange;
            const changeStr = change > 0 ? `+${change}%` : `${change}%`;
            console.log(`${item.Month}: Percentage = ${item.Perc}% ${item.Trend} (Change: ${changeStr})`);
        }
    });
    console.groupEnd();
}